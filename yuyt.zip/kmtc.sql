--------------ϵͳ�����-------------------------------------------------------------
--kmtcdb, Ӧ�ÿ�����Դ
update t_datasource set username='kmtc_uat_app5', password ='578997' where name='kmtcdb';
-- ��������Դ��ɾ����Ǭ������Դ
delete from t_datasource where name='kmtc-report';
-- ��������Դ������ϵͳ��
update t_datasource set username='kmtc_uat_sys5', password ='518997' where name='sys';

--��ѯ���浥
select item_p_status from tlk_fm_test_report;
--------------ϵͳ�����-------------------------------------------------------------

-----------------------------------���� trigger------------------------------------
create or replace 
trigger trigger_test_report_positive
AFTER INSERT OR UPDATE OF item_p_is_positive  ON TLK_FM_TEST_REPORT
FOR EACH ROW
BEGIN
 update TLK_FM_PATIENTINFO a set item_p_is_positive=:NEW.item_p_is_positive
 where a.item_p_kmbarcode=:NEW.item_p_kmbarcode 
 and a.item_p_companycode=:NEW.item_p_companycode
 and a.item_p_hospitalcode=:NEW.item_p_hospitalcode;
END;


create or replace 
trigger trigger_test_report_reimbu
AFTER INSERT OR UPDATE OF item_p_reimbu  ON TLK_FM_TEST_REPORT
FOR EACH ROW
BEGIN
 update TLK_FM_PATIENTINFO a set item_p_reimbu=:NEW.item_p_reimbu
 where a.item_p_kmbarcode=:NEW.item_p_kmbarcode
 and a.item_p_companycode=:NEW.item_p_companycode
 and a.item_p_hospitalcode=:NEW.item_p_hospitalcode;
END;

------------------------------------ɾ��Ӧ�ÿ�����-------------------------------------

-- ������Ϣ��־��������
create sequence seq_t_msg_log
create table t_msg_log(id number(20),enable varchar(1),msg_type varchar2(10),docid varchar2(50),sub_company varchar2(10),hospital varchar2(10),km_barcode varchar2(20), direction varchar2(10),msg clob,create_time timestamp,status varchar2(8)),upd_timestamp date;

--ɾ����ʱ����
DELETE FROM tlk_fm_errormonitor;

--ɾ���ѷ�����Ϣ
DELETE FROM tlk_fm_msgsend;

--ɾ��������Ϣ
DELETE FROM tlk_fm_patientinfo;

--ɾ�����浥
DELETE FROM tlk_fm_test_report;

delete from t_msg_log;
--�ύ
commit;
---------------------------------ɾ��Ӧ�ÿ�����----------------------------

--�鿴����
SELECT * FROM tlk_fm_msgsend;
select item_p_status, id docid, item_p_mobileno destnumbers, item_p_msgcontent msg, item_p_companycode sub_company, item_p_hospitalcode hospital, item_p_kmbarcode km_barcode from tlk_fm_msgsend where id in ('11e4-ca1f-e3aa19a7-847c-07e50c23495c','11e4-c884-b70d7c9d-8f0b-ffe498d499a0')
select id docid, item_p_mobileno destnumbers, item_p_msgcontent msg, item_p_companycode sub_company, item_p_hospitalcode hospital, item_p_kmbarcode km_barcode from tlk_fm_msgsend where ((item_p_status is null) or (item_p_status!='0' and item_p_status!='1')) and id not in ( select docid from t_msg_log where msg_type='SMS' )
select * from t_msg_log where msg_type in('SMS', 'SMS_RES');



--�����ϴ��걾
--��ѯ���ϴ��ı걾��Ϣ
select * from tlk_fm_patientinfo where (item_p_status='1004' and item_p_reimbu='Y');
select t1.id doc_id, t1.author author, t1.applicationid applicationid, t1.item_p_checktype item_p_checktype, t1.item_p_programs item_p_programs, t1.item_p_kmbarcode item_p_kmbarcode, t1.item_p_hospitalbarcode item_p_hospitalbarcode, t1.item_p_mobileno item_p_mobileno, t1.item_p_name item_p_name, t1.item_p_sex item_p_sex, t1.item_p_nation item_p_nation, t1.item_p_borndate item_p_borndate, t1.item_p_idno item_p_idno, t1.item_p_address item_p_address, t1.item_p_collector item_p_collector, t1.item_p_collectiontiime item_p_collectiontiime, t1.item_p_registrar item_p_registrar, t1.item_p_registrationtime item_p_registrationtime, t1.item_p_companycode item_p_companycode, t1.item_p_hospitalcode item_p_hospitalcode, t1.item_p_status item_p_status,t1.item_p_hospitalname item_p_hospitalname, t2.item_p_test_name item_p_test_name from tlk_fm_patientinfo t1, tlk_fm_datadict_test t2 where t1.item_p_status='1002' and (t1.item_p_upstatus!='0' or t1.item_p_upstatus is null) and t1.item_p_companycode = t2.item_p_companycode and t1.item_p_programs = t2.item_p_test_code
select t1.id doc_id, t1.author author, t1.applicationid applicationid, t1.item_p_checktype item_p_checktype, t1.item_p_programs item_p_programs, t1.item_p_kmbarcode item_p_kmbarcode, t1.item_p_hospitalbarcode item_p_hospitalbarcode, t1.item_p_mobileno item_p_mobileno, t1.item_p_name item_p_name, t1.item_p_sex item_p_sex, t1.item_p_nation item_p_nation, t1.item_p_borndate item_p_borndate, t1.item_p_idno item_p_idno, t1.item_p_address item_p_address, t1.item_p_collector item_p_collector, t1.item_p_collectiontiime item_p_collectiontiime, t1.item_p_registrar item_p_registrar, t1.item_p_registrationtime item_p_registrationtime, t1.item_p_companycode item_p_companycode, t1.item_p_hospitalcode item_p_hospitalcode, t1.item_p_status item_p_status,t1.item_p_hospitalname item_p_hospitalname from tlk_fm_patientinfo t1 where item_p_kmbarcode='test15031203'
select * from tlk_fm_test_report where id='11e4-cc9b-4a9603ec-baa2-15ca1bce5f79'
select * from t_msg_log where msg_type like '%US%' and sub_company='10.1';
-------------��ԭ�걾״̬Ϊδ�ϴ���MQ״̬
update t_msg_log set status='N' where msg_type like '%US%' and sub_company='10.1';
commit;
-------------��ԭ�걾״̬Ϊδ�ϴ���MQ״̬
select * from t_msg_log where msg_type='QR' and (status = 'N' or (status='O' and ROUND(TO_NUMBER(current_date-upd_timestamp) * 24 * 60 * 60)>60))
select * from t_msg_log order by id desc;
select count(*) from t_msg_log
update t_msg_log set status='O' where id=20108;
update tlk_fm_patientinfo set item_p_status='1002', item_p_upstatus =  null where item_p_kmbarcode like '0110855048%';
delete from t_msg_log where km_barcode like '0110855048%';
commit;
------------------------------------------���Բ�ѯ���浥�ű�
select * from tlk_fm_patientinfo where item_p_kmbarcode='0110855046-01'
select * from tlk_fm_test_report where item_p_kmbarcode='0110855046-01'
 SELECT * FROM (select *  from tlk_fm_test_report  WHERE ((item_p_status='0' or item_p_status='1') and item_p_parentid='11e4-cf99-a7781cff-9e15-958dbb690450')) table_0 WHERE table_0.DOMAINID ='11e4-9001-771306cc-8f62-43c551eed6f4'
select *  from tlk_fm_test_report  WHERE  item_p_parentid='11e4-cf99-a7781cff-9e15-958dbb690450' 
select t1.id doc_id, t1.item_p_kmbarcode item_p_kmbarcode, t1.item_p_hospitalcode item_p_hospitalcode,t1.item_p_companycode item_p_companycode, t1.item_p_parentid spec_doc_id from tlk_fm_test_report t1 where (item_p_status='chk' or item_p_status='211') and t1.id  not in (select t2.docid from t_msg_log t2 where t2.msg_type='QR')
--���±걾Ϊ���ϴ���LIS
select timestamp_to_scn(sysdate) scn2 from dual; 
create table t (c_d date);
insert into t (c_d) values (current_timestamp);
select ROUND(TO_NUMBER(current_date-c_d) * 24 * 60 * 60) from t 
select (current_timestamp-upd_timestamp)/1000 from t_msg_log where upd_timestamp is not null

select * from t_msg_log where msg_type='QR' and status='O' and ROUND(TO_NUMBER(current_date-upd_timestamp) * 24 * 60 * 60)>60

select * from t_msg_log  order by id desc;
select * from t_msg_log  where km_barcode= '0110855046-01' and msg_type='QR';
update tlk_fm_test_report set item_p_status='chk', item_p_reportfile = null where item_p_kmbarcode='test15032101';
update tlk_fm_patientinfo set item_p_status = '1002', item_p_upstatus ='0' where item_p_kmbarcode='test15032101';
delete from t_msg_log where km_barcode= 'test15032101' and msg_type='QR_RES';
delete from t_msg_log where km_barcode= 'test15032101' and msg_type='QR';
select t1.id doc_id, t1.item_p_kmbarcode item_p_kmbarcode, t1.item_p_hospitalcode item_p_hospitalcode,t1.item_p_companycode item_p_companycode, t1.item_p_parentid spec_doc_id from tlk_fm_test_report t1 where (item_p_status='chk' or item_p_status='211') and t1.id  not in (select t2.docid from t_msg_log t2 where t2.msg_type='QR');
commit;

select * from t_msg_log order by id desc;

select * from tlk_fm_patientinfo where item_p_kmbarcode=;
select t1.id doc_id, t1.item_p_kmbarcode item_p_kmbarcode, t1.item_p_hospitalcode item_p_hospitalcode,t1.item_p_companycode item_p_companycode, t1.item_p_parentid spec_doc_id from tlk_fm_test_report t1 where (item_p_status='chk' or item_p_status='211') and t1.id  not in (select t2.docid from t_msg_log t2 where t2.msg_type='QR')
delete from t_msg_log where id in(19462,19463);
commit;
select t1.id doc_id, t1.item_p_kmbarcode item_p_kmbarcode, t1.item_p_hospitalcode item_p_hospitalcode,t1.item_p_companycode item_p_companycode, t1.item_p_parentid spec_doc_id from tlk_fm_test_report t1 where (item_p_status='chk' or item_p_status='211') and t1.id  not in (select t2.docid from t_msg_log t2 where t2.msg_type='QR')
select docid doc_id, msg from t_msg_log where msg_type='QR'and status = 'N'
select t1.id doc_id, t1.item_p_kmbarcode item_p_kmbarcode, t1.item_p_hospitalcode item_p_hospitalcode,t1.item_p_companycode item_p_companycode from tlk_fm_test_report t1 where (item_p_status='chk' or item_p_status='211') 
and t1.id  not in (select t2.docid from t_msg_log t2 where t2.msg_type='QR')
select * from tlk_fm_test_report where item_p_kmbarcode='0110855039-01';
--��ԭ��Ϣ��־
update t_msg_log set msg='<?xml version="1.0" encoding="UTF-8"?><Data><hospCode>01.12.0054</hospCode><companyCode>01.1</companyCode><doc_id>xxx</doc_id><requestCode>0115022819</requestCode></Data>'
,status='N'
where docid in('11e4-b34b-3e910ce6-96c0-8328ec1bb136');
select * from t_msg_log where km_barcode in ('0110855019','0110855023')  order by id desc;
where docid='11e4-cc9b-6dbce2b5-baa2-15ca1bce5f79'
where msg_type in('QR','QR_RES');
delete from t_msg_log where msg_type in ('QR','QR_RES');

--��ԭ�걾��ϢΪ�����ѽ���
select * from tlk_fm_patientinfo where item_
where item_p_kmbarcode like '0110855033%';
update tlk_fm_patientinfo set item_p_status='1002' ,item_p_upstatus = null where item_p_kmbarcode like '0110855039%';
update tlk_fm_test_report set item_p_is_positive='X', item_p_status='chk', item_p_reportfile = null where item_p_kmbarcode like '01108550369%';
delete from t_msg_log where msg_type in('QR','QR_RES')  and km_barcode like '0110855039%';

commit;

update tlk_fm_patientinfo set item_p_status='1005',item_p_rpstatus= :#doc_id, item_p_sortvalue='1' where exists (select item_p_parentid from tlk_fm_test_report where id=:#doc_id)
update tlk_fm_patientinfo t1 set t1.item_p_status='1006', t1.item_p_rpstatus= '11e4-cd47-cab0e538-baa2-15ca1bce5f79', t1.item_p_sortvalue='1' where t1.id in (select t2.item_p_parentid from tlk_fm_test_report t2 where t2.id = '11e4-cd47-cab0e538-baa2-15ca1bce5f79')

update tlk_fm_patientinfo t1  set item_p_status='1006', item_p_rpstatus='123', item_p_sortvalue='1' where t1.id in (select t2.id from tlk_fm_test_report t2 where t2.id = '123');

update tlk_fm_patientinfo set item_p_status='1006', item_p_rpstatus= :#doc_id, item_p_sortvalue='1' where id in (select item_p_parentid from tlk_fm_test_report where id =:#doc_id )
--���������ٻ�
--��ԭ��Ϣ״̬
update tlk_fm_msgsend set item_p_status = null where id in ('11e4-c884-b70d7c9d-8f0b-ffe498d499a0','11e4-ca1f-e3aa19a7-847c-07e50c23495c'); 
--ɾ����Ϣ��־
delete from t_msg_log where msg_type in('SMS', 'SMS_RES');
select * from t_msg_log where msg_type in('SMS', 'SMS_RES');
update tlk_fm_patientinfo set item_p_mobileno='13611415083' where item_p_kmbarcode='0109545134-01';
commit;

---------------------------------------------------�����ٻ�
select id doc_id, item_p_mobileno destnumbers, item_p_msgcontent msg, item_p_companycode sub_company, item_p_hospitalcode hospital, item_p_kmbarcode km_barcode from tlk_fm_msgsend where ((item_p_status is null) or (item_p_status!='0' and item_p_status!='1')) and id not in ( select docid from t_msg_log where msg_type='SMS' )
select * from tlk_fm_msgsend;